# Joyful Development with Symfony

Well hi there! This repository holds the code and script
for the Symfony course on KnpUniversity.

## Have some Ideas or Feedback?

And as always, thanks so much for your support and letting us do what
we love!

If you have suggestions or questions, please feel free to
open an issue or message us.

<3 Your friends at KnpUniversity
